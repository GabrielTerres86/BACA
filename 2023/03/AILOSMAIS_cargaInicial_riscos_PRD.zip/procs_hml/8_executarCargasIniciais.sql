DECLARE
  vr_dscritic VARCHAR2(4000);
  vr_exc_erro EXCEPTION;
  
  vr_cdcooper INTEGER;
  vr_dtrefini DATE;
  vr_dtreffim DATE;
  
  TYPE typ_tab_cooperativas IS TABLE OF PLS_INTEGER INDEX BY PLS_INTEGER;
  vr_tab_cooperativas typ_tab_cooperativas := typ_tab_cooperativas(1  => 0 -- VIACREDI
                                                                  ,2  => 0 -- ACREDICOOP
                                                                  ,3  => 0 -- AILOS
                                                                  ,4  => 0 -- CONCREDI   ------ INATIVA
                                                                  ,5  => 0 -- ACENTRA
                                                                  ,6  => 0 -- UNILOS
                                                                  ,7  => 0 -- CREDCREA
                                                                  ,8  => 1 -- CREDELESC
                                                                  ,9  => 0 -- TRANSPOCRED
                                                                  ,10 => 1 -- CREDICOMIN
                                                                  ,11 => 0 -- CREDIFOZ
                                                                  ,12 => 1 -- CREVISC
                                                                  ,13 => 0 -- CIVIA
                                                                  ,14 => 0 -- EVOLUA
                                                                  ,15 => 0 -- CREDIMILSUL ------ INATIVA
                                                                  ,16 => 0 -- VIACREDI AV
                                                                  ,17 => 0 -- TRANSULCRED ------ INATIVA
                                                                  );

BEGIN

  vr_dtrefini := to_date('01/01/2022', 'DD/MM/RRRR');
  vr_dtreffim := to_date(SYSDATE, 'DD/MM/RRRR'); -- sysdate (?)

  FOR idx IN vr_tab_cooperativas.first..vr_tab_cooperativas.last LOOP

    -- Se n�o for executar a cooperativa, pula para proxima
    IF vr_tab_cooperativas(idx) = 0 THEN
      CONTINUE;
    END IF;
    
    vr_cdcooper := idx; -- Cooperativa a ser executada
    
    /* Carga inicial de cooperados, insere em:
    **  tb_pessoa
    **  tb_pessoa_fisica
    **  tb_pessoa_juridica
    **  tb_cooperado_conta
    **  tb_pessoa_relacionamento
    */
    CREDITOGESTAO.pc_carregarCooperadosAimaro(pr_idcooperativa => vr_cdcooper
                                             ,pr_dscritic      => vr_dscritic);

    IF vr_dscritic IS NOT NULL THEN
      vr_dscritic := 'pc_carregarCooperadosAimaro' || vr_dscritic;
      RAISE vr_exc_erro;
    END IF;
    
    /* Carga inicial de grupos economicos, insere em:
    **  tb_grupo_economico
    **  tb_grupo_economico_integrante
    */
    CREDITOGESTAO.pc_carregarGruposAimaro(pr_idcooperativa => vr_cdcooper
                                         ,pr_dscritic      => vr_dscritic);

    IF vr_dscritic IS NOT NULL THEN
      vr_dscritic := 'pc_carregarGruposAimaro' || vr_dscritic;
      RAISE vr_exc_erro;
    END IF;
    
    /* Carga inicial de historicos da central, insere em:
    **  tb_central_risco
    **  tb_central_risco_calculo
    **  tb_central_risco_pessoa
    **  tb_central_risco_operacao
    **  tb_central_risco_operacao_vencimento
    **  tb_central_risco_operacao_cartao
    **  tb_central_risco_operacao_riscos
    */
    CREDITOGESTAO.pc_carregarCentralRisco(pr_idcooperativa => vr_cdcooper
                                         ,pr_dtrefini      => vr_dtrefini
                                         ,pr_dtreffim      => vr_dtreffim
                                         ,pr_dscritic      => vr_dscritic);
    IF vr_dscritic IS NOT NULL THEN
      vr_dscritic := 'pc_carregarCentralRisco' || vr_dscritic;
      RAISE vr_exc_erro;
    END IF;
    
    /* Carga inicial de historicos de rating, insere em:
    **  tb_risco_contrato
    **  ht_rating
    */
    CREDITOGESTAO.pc_carregarHistoricoRating(pr_idcooperativa => vr_cdcooper
                                            ,pr_dscritic      => vr_dscritic);

    IF vr_dscritic IS NOT NULL THEN
      vr_dscritic := 'pc_carregarHistoricoRating' || vr_dscritic;
      RAISE vr_exc_erro;
    END IF;
    
    /* Carga inicial de historicos de rating antigo, insere em:
    **  tb_risco_contrato
    **  ht_rating
    */
    CREDITOGESTAO.pc_carregarHistoricoRatingAntigo(pr_idcooperativa => vr_cdcooper
                                                  ,pr_dscritic      => vr_dscritic);

    IF vr_dscritic IS NOT NULL THEN
      vr_dscritic := 'pc_carregarHistoricoRatingAntigo' || vr_dscritic;
      RAISE vr_exc_erro;
    END IF;
    
    /* Carga inicial de risco/conta agravado, insere em:
    **  tb_risco_agravado
    */
    CREDITOGESTAO.pc_carregarAgravado(pr_idcooperativa => vr_cdcooper
                                     ,pr_dscritic      => vr_dscritic);
    IF vr_dscritic IS NOT NULL THEN
      vr_dscritic := 'pc_carregarHistoricoRatingAntigo' || vr_dscritic;
      RAISE vr_exc_erro;
    END IF;
    
    /* Carga inicial do ultimo 3040 (agregados), insere em:
    **  tb_arq3040_solicitacao
    **  tb_arq3040_documento
    **  tb_central_risco_pessoa
    **  tb_central_risco_operacao
    **  tb_central_risco_operacao_cartao
    **  tb_central_risco_operacao_riscos
    **  tb_arq3040_agregado
    **  tb_arq3040_agregado_operacao
    */
    CREDITOGESTAO.pc_carregar3040(pr_idcooperativa => vr_cdcooper
                                 ,pr_dscritic      => vr_dscritic);

    IF vr_dscritic IS NOT NULL THEN
      vr_dscritic := 'pc_carregar3040' || vr_dscritic;
      RAISE vr_exc_erro;
    END IF;
    
    /* Carga inicial de acordo contrato, insere em:
    **  HT_ACORDO_CONTRATO
    **/
    BEGIN
      INSERT INTO CREDITOGESTAO.HT_ACORDO_CONTRATO(idcooperativa
                                                  ,nrconta
                                                  ,nrcontrato
                                                  ,nracordo
                                                  ,cdproduto
                                                  ,cdrisco_acordo
                                                  ,tpmanutencao
                                                  ,dtpagamento_entrada)
        SELECT cdcooper
              ,nrdconta
              ,decode(cdproduto, 4, nrborder, nrctremp) nrctremp
              ,nracordo
              ,cdproduto
              ,(CASE
                  WHEN inrisco_acordo = 1 THEN 'AA'
                  WHEN inrisco_acordo = 2  THEN 'A'
                  WHEN inrisco_acordo = 3  THEN 'B'
                  WHEN inrisco_acordo = 4  THEN 'C'
                  WHEN inrisco_acordo = 5  THEN 'D'
                  WHEN inrisco_acordo = 6  THEN 'E'
                  WHEN inrisco_acordo = 7  THEN 'F'
                  WHEN inrisco_acordo = 8  THEN 'G'
                  WHEN inrisco_acordo = 9  THEN 'H'
                  WHEN inrisco_acordo = 10 THEN 'HH'
                  ELSE ''
                END) dsnivel_acordo
              ,tpmanutencao
              ,nvl(dtpagamento_entrada, SYSDATE)
          FROM (SELECT a.nracordo
                      ,a.cdcooper
                      ,a.nrdconta
                      ,CASE c.cdorigem
                         WHEN 1 THEN 10 
                         WHEN 2 THEN 90 
                         WHEN 3 THEN 90 
                         WHEN 4 THEN 3  
                         ELSE 0
                       END cdproduto
                      ,c.nrctremp
                      ,c.inrisco_acordo
                      ,a.cdsituacao
                      ,1 AS tpmanutencao
                      ,c.dtpagamento_entrada
                      ,(SELECT tc.nrborder
                          FROM cecred.tbdsct_titulo_cyber@aimaro tc
                         WHERE tc.cdcooper = a.cdcooper
                           AND tc.nrdconta = a.nrdconta
                           AND tc.nrctrdsc = c.nrctremp) nrborder
                  FROM cecred.tbrecup_acordo@aimaro          a
                      ,cecred.tbrecup_acordo_contrato@aimaro c
                 WHERE a.nracordo = c.nracordo
                   AND a.cdcooper = vr_cdcooper
                   AND c.cdmodelo = 2
                   AND a.cdsituacao = 1);
    EXCEPTION
      WHEN OTHERS THEN
        vr_dscritic := 'Erro ao inserir tbrisco_operacao_acordo: ' || SQLERRM;
        RAISE vr_exc_erro;
    END;
    
  END LOOP;
  
  /* VAI SER EXECUTADO DEPOIS QUE A ULTIMA COOPERATIVA TIVER OS COOPERADOS CARREGADOS
  ** Carga inicial de posicao dos clientes no SCR, insere em:
  **  tb_consulta_sistema_informacoes_credito
  **  tb_consulta_scr_arquivo
  **  tb_consulta_scr_pessoa
  **  tb_consulta_scr_operacao_vencimento
  */
/*  CREDITOGESTAO.pc_carregarScr(pr_dscritic => vr_dscritic);
  IF vr_dscritic IS NOT NULL THEN
    RAISE vr_exc_erro;
  END IF;*/
  
  COMMIT;
  
EXCEPTION
  WHEN vr_exc_erro THEN
    ROLLBACK;
    raise_application_error(-20010, 'Erro: ' || vr_dscritic || SQLERRM);
  WHEN OTHERS THEN
    ROLLBACK;
    raise_application_error(-20010, 'Erro: ' || SQLERRM);
END;
